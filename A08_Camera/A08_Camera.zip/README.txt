James Spinelli
Muriel Hagge